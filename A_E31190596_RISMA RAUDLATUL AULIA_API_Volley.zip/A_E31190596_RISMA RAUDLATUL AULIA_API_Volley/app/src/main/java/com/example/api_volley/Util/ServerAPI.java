package com.example.api_volley.Util;

public class ServerAPI {
    public static final String URL_DATA = "http://192.168.0.114/";
    public static final String URL_INSERT = "http://192.168.0.114/";
    public static final String URL_DELETE = "http://192.168.0.114/";
    public static final String URL_UPDATE = "http://192.168.0.114/";
}
